---
name: AgriConnect Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf3'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d5e3fc'
  on-surface: '#0d1c2e'
  on-surface-variant: '#414944'
  inverse-surface: '#233144'
  inverse-on-surface: '#eaf1ff'
  outline: '#717973'
  outline-variant: '#c1c8c2'
  surface-tint: '#3e6654'
  primary: '#002d1d'
  on-primary: '#ffffff'
  primary-container: '#1a4332'
  on-primary-container: '#85af99'
  inverse-primary: '#a4d0b9'
  secondary: '#5f5e5b'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2dd'
  on-secondary-container: '#656461'
  tertiary: '#002d13'
  on-tertiary: '#ffffff'
  tertiary-container: '#004620'
  on-tertiary-container: '#1bbf65'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c0edd4'
  primary-fixed-dim: '#a4d0b9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#264e3d'
  secondary-fixed: '#e5e2dd'
  secondary-fixed-dim: '#c9c6c2'
  on-secondary-fixed: '#1c1c19'
  on-secondary-fixed-variant: '#474743'
  tertiary-fixed: '#6dfe9c'
  tertiary-fixed-dim: '#4de082'
  on-tertiary-fixed: '#00210c'
  on-tertiary-fixed-variant: '#005227'
  background: '#f8f9ff'
  on-background: '#0d1c2e'
  surface-variant: '#d5e3fc'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-sm:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The design system is built on a narrative of "Digital Stewardship"—merging the raw, organic nature of agriculture with the precision of modern supply chain technology. The brand personality is dependable, transparent, and forward-thinking, designed to instill trust between farmers, distributors, and retailers.

The visual style is **Corporate / Modern** with a **Tactile** edge. It utilizes generous whitespace, crisp typography, and high-quality imagery of produce and soil to ground the tech-heavy marketplace in physical reality. The interface should feel "fresh" through the use of vibrant green accents and "sturdy" through well-defined layout structures.

## Colors
The "Fresh Harvest" palette is anchored by **Deep Forest Green** (#1A4332) for authority and **Sprout Green** (#4ADE80) for energy and growth. 

- **Primary:** Used for main navigation, primary actions, and brand identification.
- **Secondary (Earth/Sand):** A warm, neutral beige used for container backgrounds and subtle section separators to avoid a cold, clinical feel.
- **Functional Colors:** Success (Leaf Green) and Warning (Harvest Gold) are tuned for high visibility on both light and dark surfaces, ensuring critical supply chain alerts are never missed.
- **Surface Strategy:** Use white as the primary surface in light mode, with the secondary beige as a "grounding" layer for cards and dashboard widgets.

## Typography
**Inter** is selected for its exceptional legibility in data-dense environments like logistics dashboards and mobile marketplaces. 

- **Marketing Contexts:** Use `display-lg` and `display-sm` with tight letter-spacing to create a bold, tech-forward presence.
- **Dashboard Contexts:** Rely on `body-md` and `body-sm` for tabular data. Use `label-md` in all-caps for metadata, SKU numbers, and status indicators.
- **Weight Strategy:** Reserve Bold (700) for displays. Use Semi-Bold (600) for actionable headers and Medium (500) for primary body text to ensure high contrast against the "Earth" background colors.

## Layout & Spacing
The design system utilizes a **12-column fluid grid** for desktop and a **4-column grid** for mobile. 

- **Dashboard Layout:** A fixed left-hand navigation (280px) with a fluid content area. Use `md` (24px) spacing for internal card padding and `lg` (40px) for section margins.
- **Marketing Layout:** Centered max-width container (1280px) with `xl` (64px) vertical spacing between sections to create a premium, breathable feel.
- **Rhythm:** All spacing is based on an 8px baseline grid to maintain mathematical harmony and ease of handoff between design and engineering.

## Elevation & Depth
Hierarchy is established through **Tonal Layers** combined with **Ambient Shadows**. 

- **Level 0 (Base):** The main canvas, typically `#FFFFFF` or `#F5F2ED`.
- **Level 1 (Cards/Surface):** White cards with a very soft, diffused shadow (0px 4px 20px rgba(26, 67, 50, 0.05)). This subtle green-tinted shadow connects the element to the brand palette.
- **Level 2 (Interactive/Floating):** Used for dropdowns and active state cards. The shadow increases in spread (0px 10px 30px rgba(26, 67, 50, 0.1)).
- **Depth Cues:** Use subtle 1px borders in `#E2E8F0` for secondary UI elements (like input fields) to maintain clarity without relying solely on shadows.

## Shapes
The shape language is approachable yet professional.
- **Standard Radius:** 0.5rem (8px) for buttons and small input fields.
- **Large Radius (rounded-lg):** 1rem (16px) for standard dashboard cards and feature blocks.
- **Extra Large Radius (rounded-xl):** 1.5rem (24px) for prominent marketing cards and high-level containers.
- **Iconography:** Use a 2px stroke weight with slightly rounded corners to match the UI's geometry.

## Components
- **Buttons:** 
  - *Primary:* Deep Forest Green background, white text. 
  - *Secondary:* Outlined with 2px Forest Green, or Ghost buttons for low-priority actions.
  - *Success:* Sprout Green background with dark Forest Green text for high-contrast accessibility.
- **Cards:** White surfaces with 16px-24px corner radius. Use "Soft Earth" (#F5F2ED) for card headers or footer metadata areas to differentiate internal content sections.
- **Inputs:** Clean white backgrounds with 8px radius. Active state should use a 2px Sprout Green border and a subtle inner glow.
- **Chips:** Used for "Stock Level" or "Crop Type." High-saturation backgrounds with high-contrast text. For example, a "In Transit" chip should use a light version of the primary green with dark green text.
- **Data Tables:** Zebra-striping using the secondary earth tone for alternate rows to improve readability across long supply chain manifests.